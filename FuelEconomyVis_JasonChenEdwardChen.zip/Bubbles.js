

function Bubbles(n){
	var number;
	number = n;
	function test(){
		return number;
	}
}